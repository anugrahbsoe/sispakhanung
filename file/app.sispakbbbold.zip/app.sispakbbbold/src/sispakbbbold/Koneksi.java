/*
 ======================================================================= 
 * Nama program : 
 * Keterangan	: Memuat Koneksi
 * Nama Fie		: Koneksi.java
 ======================================================================= 
 */
package sispakbbbold;

import java.sql.DriverManager;
import java.sql.Connection;

public class Koneksi
{
	private static Connection koneksi;
	
	public static Connection getKoneksi()
	{
		if(koneksi == null)
		{
			try
			{
				String url = "jdbc:mysql://localhost/sispakbold";
				String username = "root";
				String password = "root";
				/*String url = "jdbc:mysql://180.251.179.200/salamweb_umildb";
				String username = "salamweb_umil";
				String password = "condet2014";*/
				
				DriverManager.registerDriver(new com.mysql.jdbc.Driver());
				koneksi = DriverManager.getConnection(url,username,password);
			}
			catch(Exception ex)
			{
				System.out.println(ex);
			}
		}
		return koneksi;
	}
}
