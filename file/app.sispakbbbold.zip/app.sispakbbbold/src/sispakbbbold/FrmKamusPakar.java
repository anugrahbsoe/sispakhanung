/*
 ======================================================================= 
 * Nama program : 
 * Keterangan	: Memuat Kamus Pakar
 * Nama Fie		: FrmKamusPakar.java
 ======================================================================= 
 */
package sispakbbbold;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTable;

import com.mysql.jdbc.PreparedStatement;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JTextArea;
import javax.swing.ImageIcon;
import java.awt.Toolkit;

public class FrmKamusPakar extends JFrame {

	private JPanel contentPane;
	private JLabel lblKdKamus;
	private JLabel lblKata;
	private JTextField txtKdKamus;
	private JButton btnKeluar;
	private JButton btnHapus;
	private JButton btnUbah;
	private JButton btnTambah;
	private JTable table;
	DefaultTableModel tabelModel;
	String data[] = { "KdKamus", "Kata", "Keterangan" };
	private JTextArea txaKeterangan;
	private JTextField txtKata;
	private JLabel lblKeterangan;
	private JLabel lblCari;
	private JTextField txtCari;
	private final JButton btnCari = new JButton("");
	private JPanel panel_1;
	private JLabel label;

	/**
	 * Launch the application.
	 */
	
	  /*public static void main(String[] args) { EventQueue.invokeLater(new
	  Runnable() { public void run() { try { FrmKamusPakar frame = new
	  FrmKamusPakar(); frame.setVisible(true); } catch (Exception e) {
	  e.printStackTrace(); } } }); }*/
	 

	/**
	 * Create the frame.
	 */
	public FrmKamusPakar() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(FrmKamusPakar.class.getResource("/image/konversation.png")));
		setResizable(false);
		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 507, 471);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(51, 204, 255));
		panel.setBounds(0, -14, 505, 69);
		contentPane.add(panel);

		JLabel lblMasterPakar = new JLabel("Kamus Pakar");
		lblMasterPakar.setForeground(Color.WHITE);
		lblMasterPakar
				.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 15));
		lblMasterPakar.setBounds(165, 30, 276, 29);
		panel.add(lblMasterPakar);
		
		label = new JLabel("");
		label.setIcon(new ImageIcon(FrmKamusPakar.class.getResource("/image/dialog-question.png")));
		label.setForeground(Color.WHITE);
		label.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 15));
		label.setBounds(-20, 12, 83, 60);
		panel.add(label);

		lblKdKamus = new JLabel("KdKamus :");
		lblKdKamus.setBounds(24, 104, 126, 15);
		contentPane.add(lblKdKamus);

		lblKata = new JLabel("Kata :");
		lblKata.setBounds(24, 131, 104, 15);
		contentPane.add(lblKata);

		txtKdKamus = new JTextField();
		txtKdKamus.setEnabled(false);
		txtKdKamus.setBounds(146, 102, 114, 19);
		contentPane.add(txtKdKamus);
		txtKdKamus.setColumns(10);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBackground(Color.WHITE);
		scrollPane.setBounds(24, 250, 458, 137);
		contentPane.add(scrollPane);

		tabelModel = new DefaultTableModel(null, data);
		table = new JTable();
		table.setBackground(Color.WHITE);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent me) {
				int pilih = table.getSelectedRow();
				if (pilih < 0) {
					return;
				}

				String kdkamus = (String) tabelModel.getValueAt(pilih, 0);
				txtKdKamus.setText(kdkamus);
				String kata = (String) tabelModel.getValueAt(pilih, 1);
				txtKata.setText(kata);
				String keterangan = (String) tabelModel.getValueAt(pilih, 2);
				txaKeterangan.setText(keterangan);
				btnUbah.setEnabled(true);
				btnHapus.setEnabled(true);
				btnTambah.setEnabled(false);
				btnKeluar.setEnabled(false);
			}
		});
		table.setModel(tabelModel);
		scrollPane.setViewportView(table);

		btnTambah = new JButton("Tambah");
		btnTambah.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(txtKata.getText().isEmpty()){
					JOptionPane.showMessageDialog(null,"Kata tidak boleh kosong","Perhatian!", JOptionPane.WARNING_MESSAGE);
					txtKata.requestFocus();
				}else if(txaKeterangan.getText().isEmpty()){
					JOptionPane.showMessageDialog(null,"Keterangan tidak boleh kosong","Perhatian!", JOptionPane.WARNING_MESSAGE);
					txaKeterangan.requestFocus();
					}
				else{
				try {
					Connection con = (Connection) Koneksi.getKoneksi();
					String query = "INSERT INTO Kamus VALUES(?,?,?)";
					PreparedStatement prepare = (PreparedStatement) con
							.prepareStatement(query);

					prepare.setString(1, txtKdKamus.getText());
					prepare.setString(2, txtKata.getText());
					prepare.setString(3, txaKeterangan.getText());
					prepare.executeUpdate();
					JOptionPane.showMessageDialog(null,
							"Data berhasil ditambah", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
					prepare.close();
					tampilTabel();
					Kosong();
					autoNomer("Kamus", "KM", JFrame.EXIT_ON_CLOSE);
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Data gagal ditambah",
							"Pesan", JOptionPane.ERROR_MESSAGE);
					System.out.println(ex);
					}
				}
			}
		});
		btnTambah.setForeground(Color.WHITE);
		btnTambah.setBackground(new Color(51, 204, 255));
		btnTambah.setBounds(24, 402, 96, 25);
		contentPane.add(btnTambah);

		btnUbah = new JButton("Ubah");
		btnUbah.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Connection con = (Connection) Koneksi.getKoneksi();
					String query = "UPDATE Kamus SET Kata  = ?, Keterangan  = ? WHERE KdKamus = ? ";
					PreparedStatement prepare = (PreparedStatement) con
							.prepareStatement(query);
					prepare.setString(1, txtKata.getText());
					prepare.setString(2, txaKeterangan.getText());
					prepare.setString(3, txtKdKamus.getText());
					prepare.executeUpdate();
					JOptionPane.showMessageDialog(null, "Data berhasil diubah",
							"Pesan", JOptionPane.INFORMATION_MESSAGE);
					prepare.close();
					txtKata.setText("");
					txtKdKamus.setText("");
					tampilTabel();
					Kosong();
					btnTambah.setEnabled(true);
					btnKeluar.setEnabled(true);
					btnUbah.setEnabled(false);
					btnHapus.setEnabled(false);
					autoNomer("Kamus", "KM", JFrame.EXIT_ON_CLOSE);
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Data gagal diubah",
							"Pesan", JOptionPane.ERROR_MESSAGE);
					System.out.println(ex);
				}
			}
		});
		btnUbah.setForeground(Color.WHITE);
		btnUbah.setEnabled(false);
		btnUbah.setBackground(new Color(51, 204, 255));
		btnUbah.setBounds(116, 402, 96, 25);
		contentPane.add(btnUbah);

		btnHapus = new JButton("Hapus");
		btnHapus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Connection con = (Connection) Koneksi.getKoneksi();
					String query = "DELETE FROM Kamus WHERE KdKamus = ?";
					PreparedStatement prepare = (PreparedStatement) con
							.prepareStatement(query);

					prepare.setString(1, txtKdKamus.getText());
					prepare.executeUpdate();
					JOptionPane.showMessageDialog(null,
							"Data berhasil dihapus", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
					prepare.close();
					tampilTabel();
					Kosong();
					btnTambah.setEnabled(true);
					btnKeluar.setEnabled(true);
					btnUbah.setEnabled(false);
					btnHapus.setEnabled(false);
					autoNomer("Kamus", "K", JFrame.EXIT_ON_CLOSE);
				} catch (Exception ex) {
					System.out.println(ex);
					JOptionPane.showMessageDialog(null, "Data gagal diupdate",
							"Pesan", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		btnHapus.setForeground(Color.WHITE);
		btnHapus.setBackground(new Color(51, 204, 255));
		btnHapus.setEnabled(false);
		btnHapus.setBounds(208, 402, 96, 25);
		contentPane.add(btnHapus);

		btnKeluar = new JButton("Keluar");
		btnKeluar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Keluar();
			}
		});
		btnKeluar.setForeground(Color.WHITE);
		btnKeluar.setBackground(new Color(51, 204, 255));
		btnKeluar.setBounds(386, 402, 96, 25);
		contentPane.add(btnKeluar);

		lblKeterangan = new JLabel("Keterangan :");
		lblKeterangan.setBounds(24, 158, 104, 15);
		contentPane.add(lblKeterangan);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(149, 155, 335, 58);
		contentPane.add(scrollPane_1);

		txaKeterangan = new JTextArea();
		txaKeterangan.setDocument(new Setvalidator(150, true));
		scrollPane_1.setViewportView(txaKeterangan);

		txtKata = new JTextField();
		txtKata.setDocument(new Setvalidator(50, true));
		txtKata.setColumns(10);
		txtKata.setBounds(146, 129, 229, 19);
		contentPane.add(txtKata);

		lblCari = new JLabel("Cari :");
		lblCari.setBounds(234, 225, 104, 15);
		contentPane.add(lblCari);

		txtCari = new JTextField();
		txtCari.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cariKamusPakar();
			}
		});
		txtCari.setColumns(10);
		txtCari.setBounds(282, 225, 166, 19);
		contentPane.add(txtCari);
		btnCari.setIcon(new ImageIcon(FrmKamusPakar.class.getResource("/image/system-search.png")));

		btnCari.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				cariKamusPakar();
			}
		});
		btnCari.setBounds(455, 225, 27, 20);
		contentPane.add(btnCari);
		btnCari.setForeground(Color.WHITE);
		btnCari.setBackground(Color.BLACK);
		
		panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 0, 0));
		panel_1.setBounds(0, 53, 505, 10);
		contentPane.add(panel_1);
		setLocationRelativeTo(null);

		tampilTabel();
		autoNomer("Kamus", "KM", JFrame.EXIT_ON_CLOSE);// table_name,set_awal,frame
	}

	void cariKamusPakar(){
		try{
			/*Class.forName("com.mysql.jdbc.Driver").newInstance();	
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/sistempakar", "root", "root");*/
			Connection con = (Connection) Koneksi.getKoneksi();
			Statement state = con.createStatement();
			String sql = "select * from Kamus where KdKamus like '%" + txtCari.getText()+ "%'" +
					"or Kata like '%" + txtCari.getText() + "%'";
			ResultSet rs = state.executeQuery(sql);
			while (rs.next()) {
			tabelModel.addRow(new Object[]{
			rs.getString(1),
			rs.getString(2),
			rs.getString(3)
			});
			}
			table.setModel(tabelModel);
			//tampilTabel();
			txtCari.setText("");
			}catch (Exception e){
				System.out.println(e);
			}
			}
	
	public String autoNomer(String tabel, String strAwal, Integer pnj) {
		String auto = "";
		String s, s1;
		Integer j;
		try {
			//Connection con = (Connection) Koneksi.getKoneksi();
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/sistempakar",
			"root","root");
			//Connection con=DriverManager.getConnection("jdbc:mysql://192.168.1.123/sistempakar",
				//	"root","root");
			java.sql.Statement stat = con.createStatement();
			ResultSet rs = stat.executeQuery("select * from " + tabel);
			rs.last();

			s = Integer.toString(rs.getRow() + 1);
			j = s.length();
			s1 = "";
			for (int i = 1; i <= pnj - j; i++) {
				s1 = s1 + "0";
			}
			rs.close();
			stat.close();
			auto = strAwal + s1 + s;
			txtKdKamus.setText(auto);

		} catch (Exception e) {
			System.out.println("Pesan Error : " + e);
			JOptionPane.showMessageDialog(null,
					"Maaf, Query tidak bisa dijalankan...!!!!");
		}
		return auto;
	}

	public void tampilTabel() {
		try {
			hapusIsiTabel();
			Connection con = (Connection) Koneksi.getKoneksi();
			Statement state = con.createStatement();
			String query = "SELECT * FROM Kamus";
			ResultSet rs = state.executeQuery(query);
			while (rs.next()) {

				Object obj[] = new Object[3];
				obj[0] = rs.getString(1);
				obj[1] = rs.getString(2);
				obj[2] = rs.getString(3);
				tabelModel.addRow(obj);
				sesuaikanKolom();
			}
			rs.close();
			state.close();
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	void sesuaikanKolom() {
		// cara untuk menyesuaikan kolom dari tabel adalah mengambil
		// lebar kolom yang ada kemudian sesuaikan
		TableColumnModel modelKolom = table.getColumnModel();

		for (int kol = 0; kol < modelKolom.getColumnCount(); kol++) {
			int lebarKolomMax = 0;
			for (int baris = 0; baris < table.getRowCount(); baris++) {
				TableCellRenderer rend = table.getCellRenderer(baris, kol);
				Object nilaiTablel = table.getValueAt(baris, kol);
				Component comp = rend.getTableCellRendererComponent(table,
						nilaiTablel, false, false, baris, kol);
				lebarKolomMax = Math.max(comp.getPreferredSize().width,
						lebarKolomMax);
			}// akhir for baris
			TableColumn kolom = modelKolom.getColumn(kol);
			kolom.setPreferredWidth(lebarKolomMax);
		}// akhir for kolom
	}

	public void hapusIsiTabel() {
		int a = table.getRowCount();
		int brs;

		for (brs = 0; brs < a; brs++) {
			tabelModel.removeRow(0);
		}
	}

	void Keluar() {
		try {
			int reply = JOptionPane.showConfirmDialog(this,
					"Yakin Mau Keluar?", "Sistem - Keluar",
					JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			if (reply == JOptionPane.YES_OPTION) {
				setVisible(false); // Menyembunyikan Frame.
				dispose(); // Membersihkan Resource dari system memori
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Membebaskan
																// aplikasi dari
																// memori
				// System.exit (0); //Keluar dari Aplikasi.
			}
		} catch (Exception ex) {
		}
	}

	void Kosong() {
		txtKata.setText("");
		txaKeterangan.setText("");
	}
}
