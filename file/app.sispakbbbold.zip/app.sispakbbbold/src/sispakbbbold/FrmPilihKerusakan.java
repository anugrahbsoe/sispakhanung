/*
 ======================================================================= 
 * Nama program : 
 * Keterangan	: Memuat pilihan kerusakan
 * Nama Fie		: FrmPilihKerusakan.java
 ======================================================================= 
 */

package sispakbbbold;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;
import java.sql.DriverManager;

import javax.swing.JComboBox;
import javax.swing.JButton;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import javax.swing.JLabel;
import javax.swing.border.LineBorder;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.DefaultComboBoxModel;
import java.awt.Toolkit;

public class FrmPilihKerusakan extends JFrame {

	private JPanel contentPane;
	public JComboBox cmbPilihKerusakan;
	public JLabel lblIdKerusakan;
	private JButton btnProses;
	private JLabel lblPilihKerusakanTerjadi;
	private JPanel panel;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmPilihKerusakan frame = new FrmPilihKerusakan();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public FrmPilihKerusakan() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(FrmPilihKerusakan.class.getResource("/image/konversation.png")));
		setTitle("--Pilih Kerusakan--");
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e) {
				isiKombo();
			}
		});
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 390, 245);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(51, 204, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);

		cmbPilihKerusakan = new JComboBox();
		cmbPilihKerusakan.setBackground(Color.WHITE);
		cmbPilihKerusakan.setModel(new DefaultComboBoxModel(
				new String[] { "--Pilih--" }));
		cmbPilihKerusakan.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				isiKode();

			}
		});
		cmbPilihKerusakan.setBounds(92, 81, 193, 24);
		contentPane.add(cmbPilihKerusakan);

		btnProses = new JButton("Proses");
		btnProses.setForeground(Color.WHITE);
		btnProses.setBackground(Color.BLACK);
		btnProses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (cmbPilihKerusakan.getSelectedIndex() == 0) {
					JOptionPane.showMessageDialog(null,
							"Pilih salah satu kemungkinan", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
				} else {
					dispose();
					FrmDiagnosa DP = new FrmDiagnosa();
					DP.getIdKerusakan().setText(lblIdKerusakan.getText());
					DP.getNmKerusakan().setText(
							(String) cmbPilihKerusakan.getSelectedItem());
					DP.setVisible(true);
				}
			}
		});
		btnProses.setBounds(123, 139, 117, 25);
		contentPane.add(btnProses);

		lblIdKerusakan = new JLabel("");
		lblIdKerusakan.setVisible(false);
		lblIdKerusakan.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblIdKerusakan.setBounds(51, 104, 70, 24);
		contentPane.add(lblIdKerusakan);

		lblPilihKerusakanTerjadi = new JLabel("Pilih kerusakan terjadi pada :");
		lblPilihKerusakanTerjadi.setBounds(92, 50, 218, 15);
		contentPane.add(lblPilihKerusakanTerjadi);
		
		panel = new JPanel();
		panel.setBackground(new Color(0, 0, 0));
		panel.setBounds(0, 0, 388, 10);
		contentPane.add(panel);
	}

	void isiKombo() {
		try {
			//Connection konek = (Connection) Koneksi.getKoneksi();
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/sispakbold",
			"root","root");
			//Class.forName("com.mysql.jdbc.Driver").newInstance();
			//Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://192.168.1.123/sistempakar",
				//	"root","root");
			Statement st = (Statement) con.createStatement();
			String sql = "SELECT * FROM Kerusakan ORDER BY IdKerusakan ASC";
			ResultSet rs = (ResultSet) st.executeQuery(sql);
			while (rs.next()) {
				cmbPilihKerusakan.addItem(rs.getString("NmKerusakan"));
			}
			st.close();
			con.close();
		} catch (Exception ex) {
			System.out.println("tak terdeteksi");
		}
	}

	void isiKode() {
		try {
			// String idgejala = "";
			//Connection konek = (Connection) Koneksi.getKoneksi();
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/sispakbold",
			"root","root");
			//Class.forName("com.mysql.jdbc.Driver").newInstance();
			//Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://192.168.1.123/sistempakar",
			//"root","root");
			Statement state = (Statement) con.createStatement();
			String sql = "SELECT IdKerusakan FROM Kerusakan WHERE NmKerusakan = '"
					+ cmbPilihKerusakan.getSelectedItem() + "'";
			ResultSet rs = (ResultSet) state.executeQuery(sql);
			while (rs.next()) {
				lblIdKerusakan.setText(rs.getString("IdKerusakan"));
			}
			rs.close();
			con.close();
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "data tidak teridentifikasi",
					"Pesan", JOptionPane.INFORMATION_MESSAGE);
		}
	}
	
	
}
