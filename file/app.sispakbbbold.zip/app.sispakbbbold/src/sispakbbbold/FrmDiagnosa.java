/*
 ======================================================================= 
 * Nama program : 
 * Keterangan	: Memuat diagnosa
 * Nama Fie		: FrmDiagnosa.java
 ======================================================================= 
 */

package sispakbbbold;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;
import java.sql.DriverManager;

import javax.swing.JLabel;
import javax.swing.border.LineBorder;
import javax.swing.JButton;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Font;
import javax.swing.ImageIcon;

public class FrmDiagnosa extends JFrame {

	private JPanel contentPane;
	private JLabel lblKode;
	private JLabel lblDiagnosis;
	private JButton btnYa;
	private JButton btnTidak;
	public FrmPilihKerusakan pilihkerusakan = new FrmPilihKerusakan();
	private JPanel panel_1;
	private JLabel lblSatu;
	private JPanel panel;
	private JLabel lblApakah;
	private JLabel label;
	private JPanel panel_2;

	/**
	 * Launch the application.
	 */
	
	  /*public static void main(String[] args) { EventQueue.invokeLater(new
	  Runnable() { public void run() { try { FrmDiagnosa frame = new
			  FrmDiagnosa(); frame.setVisible(true); } catch (Exception e) {
	  e.printStackTrace(); } } }); }*/
	 

	/**
	 * Create the frame.
	 */
	public FrmDiagnosa() {
		setTitle("Diagnosa");
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowActivated(WindowEvent e) {
				//hapusTemp();
				simpanTemp();
				cariKerusakan();
			}
		});
		setBounds(100, 100, 436, 218);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		setUndecorated(true);
		
		lblKode = new JLabel("");
		lblKode.setVisible(false);
		lblKode.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblKode.setBounds(28, 54, 70, 24);
		contentPane.add(lblKode);

		lblDiagnosis = new JLabel("");
		lblDiagnosis.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblDiagnosis.setBounds(115, 95, 273, 24);
		contentPane.add(lblDiagnosis);

		btnYa = new JButton("Ya");
		btnYa.setForeground(Color.WHITE);
		btnYa.setBackground(new Color(51, 204, 255));
		btnYa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					if(lblKode.getText().contains("E") || lblKode.getText().contains("D") || lblKode.getText().contains("C") || lblKode.getText().contains("B") || lblKode.getText().contains("A")){	
						try {
							simpanTemp(); // tambahan
							//Connection con = (Connection) Koneksi.getKoneksi();
							Class.forName("com.mysql.jdbc.Driver").newInstance();
							Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/sispakbold",
							"root","root");
							//Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://192.168.1.123/sistempakar",
							//		"root","root");
							Statement st = (Statement) con.createStatement();
							String sql = "SELECT Gejala.IdGejala, Gejala.NmGejala FROM Gejala, Punya_Aturan_Ya WHERE Punya_Aturan_Ya.Satu  = '"
								+ lblKode.getText()
								+ "' and Gejala.IdGejala = Punya_Aturan_Ya.Dua";
							ResultSet rs = (ResultSet) st.executeQuery(sql);
							if (rs.next()) {
								lblKode.setText(rs.getString("IdGejala"));
								lblDiagnosis.setText(rs.getString("NmGejala"));
							} else {
								new FrmHasilDiagnosa().show();
								dispose();
								}
							rs.close();
							st.close();
							}
						catch (Exception ex) {
								JOptionPane.showMessageDialog(null,
								"kerusakan tidak teridentifikasi", "Pesan",
								JOptionPane.INFORMATION_MESSAGE);
							}
						}
			}
		});
		btnYa.setBounds(115, 150, 117, 25);
		contentPane.add(btnYa);

		btnTidak = new JButton("Tidak");
		btnTidak.setForeground(Color.WHITE);
		btnTidak.setBackground(new Color(51, 204, 255));
		btnTidak.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(lblKode.getText().contains("E") || lblKode.getText().contains("D") || lblKode.getText().contains("C") || lblKode.getText().contains("B") || lblKode.getText().contains("A") || lblKode.getText().contains("F")) {
					try {
						//Connection con = (Connection) Koneksi.getKoneksi();
						Class.forName("com.mysql.jdbc.Driver").newInstance();
						Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/sispakbold",
						"root","root");
						//Class.forName("com.mysql.jdbc.Driver").newInstance();
						//Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://192.168.1.123/sistempakar",
							//	"root","root");
						Statement st = (Statement) con.createStatement();
						String sql = "SELECT Gejala.IdGejala, Gejala.NmGejala, Punya_Aturan_Tidak.Satu FROM Gejala,Punya_Aturan_Tidak WHERE Punya_Aturan_Tidak.Satu  = '"
								+ lblKode.getText()
								+ "' AND Gejala.IdGejala = Punya_Aturan_Tidak.Dua";
						ResultSet rs = (ResultSet) st.executeQuery(sql);
						if (rs.next()) {
							lblKode.setText(rs.getString(1));
							lblDiagnosis.setText(rs.getString(2));
							lblSatu.setText(rs.getString(3));
							if(lblKode.getText().contentEquals("E320")){
								dispose();
								FrmArahan arahan = new FrmArahan();
								arahan.IdKerusakan().setText(lblSatu.getText());
								arahan.setVisible(true);
								}
							if(lblKode.getText().contentEquals("E310")){	
							JOptionPane.showMessageDialog(null,"pakar belum menemukan identifikasi","Pesan",JOptionPane.INFORMATION_MESSAGE); 
								dispose(); 
								new FrmPilihKerusakan().show();
								hapusTemp();
							}
						} else {
							dispose();
						}
						rs.close();
						st.close();
					} catch (Exception ex) {
							JOptionPane.showMessageDialog(null,
							"kerusakan tidak teridentifikasi", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
						}
				}
			}
		});
		btnTidak.setBounds(244, 150, 117, 25);
		contentPane.add(btnTidak);

		lblApakah = new JLabel("Apakah");
		lblApakah.setBounds(38, 90, 70, 41);
		contentPane.add(lblApakah);
		
		panel = new JPanel();
		panel.setBackground(new Color(51, 204, 255));
		panel.setBounds(0, 0, 436, 34);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lbldiagnosa = new JLabel("--Diagnosa--");
		lbldiagnosa.setFont(new Font("Dialog", Font.BOLD, 12));
		lbldiagnosa.setForeground(Color.WHITE);
		lbldiagnosa.setBounds(153, 12, 130, 15);
		panel.add(lbldiagnosa);
		
		label = new JLabel("");
		label.setIcon(new ImageIcon(FrmDiagnosa.class.getResource("/image/search.png")));
		label.setBorder(null);
		label.setBounds(-12, 0, 77, 22);
		panel.add(label);
		
		panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(10, 37, 414, 169);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		lblSatu = new JLabel("");
		lblSatu.setVisible(false);
		lblSatu.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblSatu.setBounds(12, 110, 70, 24);
		panel_1.add(lblSatu);
		
		panel_2 = new JPanel();
		panel_2.setBackground(new Color(0, 0, 0));
		panel_2.setBounds(0, 32, 446, 10);
		contentPane.add(panel_2);
		setLocationRelativeTo(null);
	}

	public JLabel getIdKerusakan() {
		return lblKode;

	}

	public JLabel getNmKerusakan() {
		return lblDiagnosis;

	}

	void simpanTemp() {
		try {
			Connection con = (Connection) Koneksi.getKoneksi();
			String query = "INSERT INTO Temp VALUES(?,?)";
			PreparedStatement prepare = (PreparedStatement) con
			.prepareStatement(query);
			prepare.setString(1, lblKode.getText());
			prepare.setString(2, lblDiagnosis.getText());
			prepare.executeUpdate();
			prepare.close();

		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	void hapusTemp() {
		try {
			Connection con = (Connection) Koneksi.getKoneksi();
			String query = "Truncate Temp";
			PreparedStatement prepare = (PreparedStatement) con
			.prepareStatement(query);
			prepare.executeUpdate();
			prepare.close();

		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	void cariKerusakan(){
		try {
		//Connection con = (Connection) Koneksi.getKoneksi();
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/sispakbold",
				"root","root");
		Statement st = (Statement) con.createStatement();
		String sql = "SELECT Gejala.IdGejala, Gejala.NmGejala FROM Gejala, Target WHERE Gejala.IdGejala = Target.IdGejala and Target.IdKerusakan = '"
				+ lblKode.getText()
				+ "' order by Gejala.IdGejala DESC LIMIT 1";
		ResultSet rs = (ResultSet) st.executeQuery(sql);
		while (rs.next()) {
			lblKode.setText(rs.getString("IdGejala"));
			lblDiagnosis.setText(rs.getString("NmGejala"));
			}
		rs.close();
		st.close();
		} 
		
	catch (Exception ex) {
			JOptionPane.showMessageDialog(null,
			"kerusakan tidak teridentifikasi", "Pesan",
			JOptionPane.INFORMATION_MESSAGE);
		}
	}
}
